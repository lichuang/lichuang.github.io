---
title: "英雄三国服务器代码笔记"
date: 2019-03-06T09:26:21+08:00
draft: true
categories: ["work"]
---

# 基础架构

## TDataHandler
纯虚类，有以下接口：

```C
//处理连接
virtual void HandleConnect(int error) {
}
// 处理写
virtual void HandleWrite() {
}
// 处理读
virtual void HandleRead() = 0;
// 处理错误
virtual void HandleError(int error) = 0;
```

## TSocket
从Descriptor中继承下来，负责管理socket，内部有两个buffer list：读read_list_和写write_list_。

可读的时候将数据读入到read_list_，可写的时候把write_list_中的数据写出去。

另外，还有个状态保存连接状态，因为这个socket可能是对外建立连接用的。

由于采用了epoll的ET模式，属于边缘触发，所以还需要一个变量表示是否可写。

内部还有一个TDataHandler指针，用于处理socket的各种情况。

## TSession
管理一个连接，继承自TDataHandler。

# RPC

## ProtobufService
ProtobufService继承自TAcceptHandler，负责以下工作：

* 注册RPC方法：每个RPC方法有一个对应的method ID，与之关联。RPC协议中头部会带上对应的method ID用于查询对应的是哪个方法，然后再来根据具体方法进行处理。
* 管理rpc channel：内部维护一个map用于管理rpc channel，一个地址对应一个RPC channel，如果同样的地址又来了一个channel连接，将踢掉之前的rpc channel，即同一个地址只能有一个channel。内部的map可以通过多种方式访问到channel：host-port组合、地址、guid。

## PacketParser
负责RPC协议的读写。RPC协议具体的格式如下：

* 协议包头
  * 1个字节的magic number。
  * 8个字节的call guid，用于表示发送方。
  * 8个字节的method ID，为0的时候表示这是一个rpc应答消息。
  * 4个字节的包体长度。
* 包体内容：大小如包体长度所示。

内部集成了socket对象，用于收发RPC数据。

## ProtobufChannel
具体维护一个RPC连接，继承自google::protobuf::RpcChannel::RpcChannel（该类是protobuf自动生成，有纯虚函数CallMethod），以及TDataHandler,内部使用PacketParser来完成RPC协议的读写。

当写入数据的时候，如果当前还在连接状态，则首先push进入消息队列中，待连接成功了再进行发送，使用者不需要关注这个逻辑。

另外，还提供了订阅关闭事件的接口，用户可以注册一个callback来订阅这个channel关闭事件。


# Lock Service
lock service服务，本质上提供针对一个key的读写、加锁、删除、创建操作，当一个key被锁住之后，后续针对该key的请求会被记录到一个等待队列中，在解锁之后再被执行。


对外暴露以下服务：

```C
service LockService {
  rpc Read(Request) returns (Response);
  rpc Write(Request) returns (Response);
  rpc Lock(Request) returns (Response);
  rpc Unlock(Request) returns (Response);
  rpc Create(Request) returns (Response);
  rpc Delete(Request) returns (Response);
};
```

针对每个key，有一个Node结构体与之对应。当有多个请求等待在同一个key的时候，创建一个LockWaitContext信息，LockWaitContext用于缓存向Lockserver请求的信息，等待被唤醒时根据这些信息进行操作。而一个Node的所有LockWaitContext保存在Node的wait_list中。

![lockserver-operation](/media/imgs/20190306-work-sanguo/lockserver-operation.png "lockserver-operation")

有以下场景检查Node的wait_list：

* 定时查询，调用CheckWaitingRequest函数查询所有Node的wait list，针对每个Node最终还是调用ProcessNodePendingRequest来检查的。
* 当Node被Unlock时，调用ProcessNodePendingRequest检查Node的wait list。
* 当删除Node时，调用ProcessNodePendingRequest检查Node的wait list，把pending的请求都关闭。

![node-wait-list](/media/imgs/20190306-work-sanguo/node-wait-list.png "node-wait-list")

ProcessNodePendingRequest的主要逻辑：遍历Node的wait list中的LockWaitContext，做如下操作：

* 如果force_clean=true，说明该key已经被删除，返回kLockServerCancel。
* 如果超时，返回kLockTimeout。
* 检查当前Node的lock_token，如果是kInvalidToken，说明没有被加锁，直接调用对应的Do函数进行操作。否则意味着Node又被加锁了，不做任何操作。

另外，lock service提供了一个持久化存储的接口，需要的时候可以落盘数据到文件中。

## Lock Service的缺点
* 单机，没有分布式

# DOM(Distributed Object Manager)
以库的形式，提供了分布式环境下的actor服务，使用ID定位到对象所在的服务器，然后向对象发送消息。

## KeyChannel
用于向key发送消息，内部使用lockservice的locker对象封装了lockservice的访问，另外内部还有一个消息队列，用户向某个key发送的消息将首先缓存在这里，由KeyChannel来具体完成发送消息的工作，而用户不需要关注这些信息。

使用一个变量来保存当前KeyChannel的状态，如果是初始状态，那么需要首先使用locker.ReadKey来读取这个key所在的服务器信息，然后再进行消息发送。也就是说，向lock service读取一个key的value，就是这个key所在的服务器地址。

每次key的location，都对应一个版本号，收到应答包的时候会对比一下这个版本号，如果不对应的情况下将出错。

另外，如果key的value发生了变化，也就是说该key所在的服务器发生了变化，返回值中的错误码将带上location mismatch的错误。在这种情况下，key channel的操作就是：

* 递增版本号，这样回来的包版本不一致就会出错。
* 重置消息队列的队列头，这样消息队列中的消息将重新开始发送。
* 调用KeyChannel::RetrySend进行重新发送：
  * 递增重试次数，如果重试次数超过阈值将出错返回。
  * 根据当前重试次数，生成一个定时器，在超时之后调用ReadLocationThenSendRequest函数。这个函数的逻辑是：调用locker.ReadKey读取key的最新位置，然后在回调函数判断如果拿到了最新的值也就是key的location，将发送请求。重新发送时，最开始窗口大小为1，只有在发送成功之后才变大多发送一些数据。

总而言之，KeyChannel使用locker封装了对lock service的访问，通过它在一个分布式环境里对key发送消息。  

## KeyChannelManager
管理KeyChannel的，根据key或者guid来查询对应的KeyChannel对象，不存在就创建新的出来。

## DOM
对外暴露分布式对象的处理接口，包括：

* CreateKey：创建一个key
* ReadKey：读取一个key的值
* WriteKey：写入一个key的值
* SendMessageToKey：向key发送消息
* SendRawMessageToKey：向key发送原始消息
* Transfer：将一个key转移到另一个地址去。

DOM内部实现封装了locker的使用，如：

* CreateKey：调用locker_->CreateKey实现。
* DeleteKey：调用locker_->DeleteKey实现。
* WriteKey：调用locker_->WriteKey实现。
* SendMessageToKey：首先根据key查询到key channel，然后调用key_channel->SendMessage。
* Transfer：分为以下几步：
  * locker_->LockKey：锁住key，让后面的操作暂停。
  * LockKey的回调函数LockKey_Callback中：根据目的地址查询key channel，然后key_channel->Transfer。
  * Transfer的回调函数Transfer_Callback中：调用locker_->UnlockAndUpdateValue，请求中传入的flag为kUpdateValue，即更新key的新地址。

简单理解Transfer做的事情就是：锁住key，然后transfer到新的地址上，然后解锁的时候写入key的value为新的地址。可以看到，简单的向一个key发送消息，直接调用locker接口就好了；而Transfer操作需要先锁住key才行。

## DOMServiceImpl
具体实现了DomService的接口。

其实就是实现了Invoke和Transfer两个接口，两个接口都是根据某个消息，找到该消息的处理函数，然后把传过来的消息调用处理函数来处理。

区别在于：两者都会首先查询一下这个key是不是在当前的key table中，而Invoke接口在查询key失败的情况下将返回kDOM_LocationMisMatch，表示这个key不在该服务器中，这样客户端收到这个错误码的时候；而Transfer在查询key失败的情况下会插入一条新的记录，表示这个key迁移到了这里。

# 游戏服务
## 整体架构

## login_server
login server负责以下工作：

* 验证客户端请求。
* 返回realm服务器地址列表给客户端。

相关模块：

* ClientPacketParser：用于解析客户端协议，内部有该连接对应的socket对象。
* LoginSession：继承自TSession，处理客户端协议请求内部有ClientPacketParser用于解析客户端协议。
* RealmConnector：负责与realm进行RPC通信。

## realm
返回gate服务给客户端？

配置文件中配置gate的地址，内部使用了DOM。

## gate

# 遗留问题
* login server与客户端进行验证的协议，srp6？




