---
title: "实例解释Mysql的事务隔离级别"
date: 2020-08-02T16:31:32+08:00
draft: true
---


由于学习`boltdb`代码的缘故，需要了解一下`MVCC`的机制，而这又涉及到了数据库的事务级别，于是以`Mysql`数据库为例学习了一下这方面的概念。本文主要参考了[《MySQL 事务隔离级别和锁》](https://developer.ibm.com/zh/articles/os-mysql-transaction-isolation-levels-and-locks/)以及[维基百科事务隔离](https://zh.wikipedia.org/wiki/%E4%BA%8B%E5%8B%99%E9%9A%94%E9%9B%A2)。

# 概论
Mysql中，按照隔离级别的强弱，依次支持以下几种类型的事务，但是事务的隔离级别越高越安全也就意味着并发性越差：

* 读未提交（Read Uncommitted）事务，简称RU事务。
* 读已提交（Read Committed）事务，简称RC事务。
* 可重复读（Repeatable Read）事务，简称RR事务。
* 可串行化（Serializable）事务。

下面来依次使用示例和图来演示这几种事务隔离级别，所有例子在Mysql 8.0中运行。


# 读未提交事务
这是并发性最快的一种事务隔离级别，但是也是最不安全的，因为可能读取到其他事务还没有提交的数据，也就是会出现脏读（Dirty Read）现象。

首先使用`'READ-UNCOMMITTED'`隔离级别创建测试所用的表，然后插入一条id为1的数据：

```sql
SET @@session.transaction_isolation = 'READ-UNCOMMITTED';
create database test;
use test;
create table test(id int primary key);
insert into test(id) values(1);
```

然后使用两个Mysql终端，分别按照执行以下事务操作：

|步骤|  事务A   | 事务B  | 结果 |
| ---- |  ----  | ----  | ---- |
|0| SET @@session.transaction_isolation = 'READ-UNCOMMITTED';  | SET @@session.transaction_isolation = 'READ-UNCOMMITTED'; |开始之前在两个终端会话设置事务隔离级别 |
|1| begin  | begin | |
|2| update test set id = 2 where id = 1;  |  |  |
|3|  select * from test; |  | 返回id为2的数据 |
|4|   | select * from test; | 返回id为2的数据 |
|5| commit  |  | |


<center>
![readUncommitted](/media/imgs/20200801-mysql-transaction/readUncommitted.png "readUncommitted")
</center>

上图中，用户A发起了一个事务，将x的值由1修改成2，但是在该事务提交之前，用户B读到了这个还未提交的值，于是发生了脏读现象。

# 读已提交事务
读提交事务，比前面的读未提交事务隔离性要更好一些，即不会出现脏读现象，不会读到另一个事务还未提交的数据，但是它也有自己的问题：不可重复读（Repeatable Read）：即在同一次事务中，针对同一行数据的两次读操作出现了两个不同的值。

在该隔离级别中，要求对选定对象的写锁一直保持到事务结束，但是读锁在SELECT操作完成后马上释放，因此“不可重复读”现象可能会发生，见下面描述。和前一种隔离级别一样，也不要求“范围锁”。

首先使用`'READ-COMMITTED'`隔离级别创建测试所用的表，然后插入一条id为1的数据：

```sql
SET @@session.transaction_isolation = 'READ-COMMITTED';
create database test;
use test;
create table test(id int primary key);
insert into test(id) values(1);
```

然后使用两个Mysql终端，分别按照执行以下事务操作：

|步骤|  事务A   | 事务B  | 结果 |
| ---- |  ----  | ----  | ---- |
|0| SET @@session.transaction_isolation = 'READ-COMMITTED';  | SET @@session.transaction_isolation = 'READ-COMMITTED'; |开始之前在两个终端会话设置事务隔离级别 |
|1| begin  | begin | |
|2| update test set id = 2 where id = 1;  |  |  |
|3|  select * from test; |  | 返回id为2的数据 |
|4|   | select * from test; | 返回id为1的数据 |
|5| commit  |  | |
|6|   | select * from test; | 返回id为2的数据 |
|7| | commit  | |

<center>
![readCommitted](/media/imgs/20200801-mysql-transaction/readCommitted.png "readCommitted")
</center>

上图中，事务A发起了一个事务，将x的值由1修改成2，同时事务B也启动了一次事务，该事务中前后两次读x的值，但是一次读到了旧值1，一次读到的是新值2，这就是不可重复读现象。

# 可重复读事务
可重复读事务，解决了前面的问题，即在同一个事务中，读取同一行数据，结果都是一致的，即只能返回该事务开始之前的数据。但是可重复事务也有另外的问题，即所谓的“幻读（phantom read）”问题：同一个事务执行同样的一条SQL语句，但是得到不一致的结果。可见，“幻读”现象是不可重复读的特殊情况。

在该隔离级别中，要求对选定对象的读锁（read locks）和写锁（write locks）一直保持到事务结束，但不要求“范围锁”，因此可能会发生“幻读”。

首先使用`'REPEATABLE-READ'`隔离级别创建测试所用的表：

```sql
SET @@session.transaction_isolation = 'REPEATABLE-READ';
create database test;
use test;
create table test(id int primary key,name varchar(20));
```

然后使用两个Mysql终端，分别按照执行以下事务操作：

|步骤|  事务1   | 事务2  | 结果 |
| ---- |  ----  | ----  | ---- |
|0| SET @@session.transaction_isolation = 'REPEATABLE-READ';  | SET @@session.transaction_isolation = 'REPEATABLE-READ'; |开始之前在两个终端会话设置事务隔离级别 |
|1| begin  | begin | |
|2| select * from test;  |  | 无记录 |
|3|   | select * from test; | 无记录 |
|4| insert into test(id,name) values(1,'a');  |  | |
|5| commit  |  | |
|6|   | select * from test; | 无记录 |
|7| select * from test;  |  | 返回id为1的记录 |
|8|   |  insert into test(id,name) values(1,'b'); |  Duplicate entry '1' for key 'test.PRIMARY' |


<center>
![repeatableRead](/media/imgs/20200801-mysql-transaction/repeatableRead.png "repeatableRead")
</center>

上图中，事务B在事务A提交了插入数据的操作前后，返回的数据量都是0，看上去已经不存在不可重复读问题了，但是当事务B插入同一个键的数据时，却提示已经存在相同键的数据了：`Duplicate entry '1' for key 'test.PRIMARY'`，这就是幻读现象。

# 序列化事务
在序列化这个隔离级别下面执行的事务，都是串行执行的，这也意味着并发性很差。

该隔离级别要求在选定对象上的读锁和写锁保持直到事务结束后才能释放。在SELECT 的查询中使用一个“WHERE”子句来描述一个范围时应该获得一个“范围锁”（range-locks）。这种机制可以避免“幻读”（phantom reads）现象。


首先使用`'SERIALIZABLE'`隔离级别创建测试所用的表：

```sql
SET @@session.transaction_isolation = 'SERIALIZABLE';
create database test;
use test;
create table test(id int primary key);
```

|步骤|  事务1   | 事务2  | 结果 |
| ---- |  ----  | ----  | ---- |
|0| SET @@session.transaction_isolation = 'SERIALIZABLE';  | SET @@session.transaction_isolation = 'SERIALIZABLE'; |开始之前在两个终端会话设置事务隔离级别 |
|1| begin  | begin | |
|2| insert into test(id) values(1);  |  | 会话1插入一条记录 |
|3|   | select * from test; | 会阻塞直到事务A提交才返回数据 |
|4| commit  |  | |


# 事务隔离级别小结

总结一下几个隔离级别的问题：

|隔离级别|  脏读   | 不可重复读  | 幻读 |
| ---- |  ----  | ----  | ---- |
|读未提交| 可能出现  | 可能出现 | 可能出现 |
|读已提交| 不会出现  | 可能出现 | 可能出现 |
|可重复读| 不会出现  | 不会出现 | 可能出现 |
|序列化| 不会出现  | 不会出现 | 不会出现 |

不同隔离级别持有锁的持续时间如下表，其中`C`表示锁会持续到事务结束，而`S`表示锁会持续到当前语句执行完毕：

|隔离级别|  写操作   | 读操作  | 范围操作（where语句） |
| ---- |  ----  | ----  | ---- |
|读未提交| S  | S | S |
|读已提交| C  | S | S |
|可重复读| C  | C | S |
|序列化| C  | C | C |






