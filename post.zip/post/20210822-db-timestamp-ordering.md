---
title: "基于时间戳的协议"
date: 2021-08-22T22:33:50+08:00
draft: true
---

# 时间戳
定义TS(Ti)为事务Ti的时间戳，使用时间戳来决定事物之间的次序。如果`TS(Ti)<TS(Tj)`，那么系统需要保证执行顺序就像Ti在Tj之前执行的一样。

时间戳的计算，可以使用系统时钟，或者是逻辑计数器。

另外，还定义了两个时间戳：

* W-TS(X)：成功执行了Write(X)操作的任意事务的最大时间戳。
* R-TS(X)：成功执行了Read(X)操作的任意事务的最大时间戳。

基于时间戳的协议核心就在于，使用时间戳来检测操作的时间，如果发现事务试图访问一个来自于未来的对象，那么事务就中断然后使用新的时间戳重启事务。

# 基本的操作

## 读操作

* 如果`TS(Ti)<W-TS(X)`，这意味着事务T访问到了另一个更新的事务已经修改过的对象X，中断T并且使用新的时间戳重启事务。
* 否则：
  * TS(Ti)能成功执行Read(X)。
  * 更新R-TS(X)=max(R-TS(X),TS(Ti))。
  * 拷贝对象X以便事务进行重复读操作。

## 写操作

* 如果`TS(Ti)<W-TS(X)`或者`TS(Ti)<R-TS(X)`，这意味着事务T修改到了另一个更新的事务已经修改过的对象X，中断T并且使用新的时间戳重启事务。
* 否则：
  * TS(Ti)能成功执行Write(X)。
  * 更新W-TS(X)=max(W-TS(X),TS(Ti))。
  * 拷贝对象X以便事务进行重复读操作。

## 例子

以下是安全提交的例子：

<center>
![安全提交的例子](/media/imgs/20210822-db-timestamp-ordering/to-ex1.png "安全提交的例子")
</center>

上图中，计算得到的R-TS和W-TS都没有问题，所以两个事务都能安全提交。

以下是失败提交的例子：

<center>
![失败提交的例子](/media/imgs/20210822-db-timestamp-ordering/to-ex2.png "失败提交的例子")
</center>

上图中，由于2的W(A)比T1的W(A)操作有更大的时间戳，所以T2能成功提交，而T1需要中断并重启。

## Thomas写规则（Thomas write rule）
Thomas写规则与一般时间戳协议的区别在于：

* 如果`TS(Ti)<R-TS(X)`，中断并重启事务Ti。
* 如果`TS(Ti)<W-TS(X)`，时间戳协议要求中断并重启事务Ti，但是Thomas写规则可以忽略这个写操作并继续执行事务。

例子如下：

<center>
![Thomas写规则的例子](/media/imgs/20210822-db-timestamp-ordering/thomas.png "Thomas写规则的例子")
</center>

上图中，事务T1的W(A)操作违反了时间戳协议，按照时间戳协议应该中断T1并重启。但是按照thomas写规则可以忽略事务T1的W(A)操作，并且继续T1的执行。这样，在外部看来，W-TS(A)还是2。

# 乐观的并发控制（OPTIMISTIC CONCURRENCY CONTROL，简称OCC）

分为三阶段：

* 读阶段：
* 检查阶段：
* 写阶段：

