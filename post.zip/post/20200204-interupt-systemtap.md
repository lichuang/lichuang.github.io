---
title: "通过Systemtap探索Linux系统之软中断"
date: 2020-02-04T22:17:08+08:00
draft: true
---

# 概述

# 中断的下半部

# 软中断

## 数据结构
软中断由系统在启动的时候注册到内核中，由一个全局数组来维护软中断：

```C
struct softirq_action
{
	void	(*action)(struct softirq_action *);
};

static struct softirq_action softirq_vec[NR_SOFTIRQS] __cacheline_aligned_in_smp;
```

可以看到，本质上结构体softirq_action存储的是函数指针而已，软中断有以下类型：

```C
enum
{
	HI_SOFTIRQ=0,
	TIMER_SOFTIRQ,
	NET_TX_SOFTIRQ,
	NET_RX_SOFTIRQ,
	BLOCK_SOFTIRQ,
	IRQ_POLL_SOFTIRQ,
	TASKLET_SOFTIRQ,
	SCHED_SOFTIRQ,
	HRTIMER_SOFTIRQ, 
	RCU_SOFTIRQ,
	NR_SOFTIRQS
};
```

系统提供了open_softirq函数用于各个需要使用到软中断的系统注册对应的软中断处理函数。

```C
void open_softirq(int nr, void (*action)(struct softirq_action *))
{
	softirq_vec[nr].action = action;
}
```

同时，还提供了softirq_to_name数组，用于把软中断的索引映射到对应的软中断名称：

```C
const char * const softirq_to_name[NR_SOFTIRQS] = {
	"HI", "TIMER", "NET_TX", "NET_RX", "BLOCK", "IRQ_POLL",
	"TASKLET", "SCHED", "HRTIMER", "RCU"
};
```
在Linux下面，可以通过查看`/proc/softirqs`文件知道当前系统软中断的情况：

```
$ cat /proc/softirqs
                    CPU0       CPU1       CPU2       CPU3
          HI:     276180     286764    2509097     254357
       TIMER:    1550133    1285854    1440533    1812909
      NET_TX:     102895         16         15         57
      NET_RX:        155        178        115    1619192
       BLOCK:       1713      15048     251826       1082
    IRQ_POLL:          0          0          0          0
     TASKLET:          9         63          6       2830
       SCHED:    1484942    1207449    1310735    1724911
     HRTIMER:          0          0          0          0
         RCU:     690954     685825     787447     878963
```

## 触发软中断
触发软中断的入口函数是raise_softirq：

```C
void raise_softirq(unsigned int nr)
{
	unsigned long flags;

	local_irq_save(flags);
	raise_softirq_irqoff(nr);
	local_irq_restore(flags);
}
```

首先，由于调用软中断处理函数必须禁用中断，所以local_irq_save宏将保存在eflags寄存器中的IF标志，同时禁用本地处理器的中断。对应的，local_irq_restore宏将保存下来的flags标志位恢复回去，同时打开本地处理器的中断。

接着看raise_softirq_irqoff函数：

```C
inline void raise_softirq_irqoff(unsigned int nr)
{
	__raise_softirq_irqoff(nr);

	if (!in_interrupt())
		wakeup_softirqd();
}
```

首先，调用`__raise_softirq_irqoff`将本地处理器的中`__softirq_pending`变量对应nr这个软中断的位置为1，表示该类型的软中断被触发了。

然后，通过`in_interrupt`函数来判断处理器当前是否在处理中断状态，如果没有则调用`wakeup_softirqd`函数唤醒本处理器的`ksoftirqd`内核进程：

```C
static void wakeup_softirqd(void)
{
	struct task_struct *tsk = __this_cpu_read(ksoftirqd);

	if (tsk && tsk->state != TASK_RUNNING)
		wake_up_process(tsk);
}
```

在Linux系统中，每个CPU都会运行一个`ksoftirqd`内核进程，专门由这个进程来处理本CPU的软中断。

总结来说，要触发一个软中断只需要以下几步：

1.  保存IF标志，禁用中断。
2.  将这个软中断对应的位置为1。
3.  通知本CPU的ksoftirqd内核进程，有软中断需要处理。
4.  恢复IF标志，开启中断。

可以看到，有了软中断机制，内核在禁用中断的状态中实际上并没有耗费太多时间，因为并没有在这个过程里面具体处理中断。

# tasklet
软中断的问题在于，只能在系统启动时注册，另外数量和类型不能动态变更，因此基于软中断之上又实现tasklet，这是最常见的实现延迟中断处理的机制。

首先来看初始化，对应的是softirq_init函数：

```C
void __init softirq_init(void)
{
	int cpu;

	for_each_possible_cpu(cpu) {
		per_cpu(tasklet_vec, cpu).tail =
			&per_cpu(tasklet_vec, cpu).head;
		per_cpu(tasklet_hi_vec, cpu).tail =
			&per_cpu(tasklet_hi_vec, cpu).head;
	}

	open_softirq(TASKLET_SOFTIRQ, tasklet_action);
	open_softirq(HI_SOFTIRQ, tasklet_hi_action);
}
```

可以看到，tasklet各有一个基于TASKLET_SOFTIRQ和HI_SOFTIRQ两个类型软中断的tasklet，变量tasklet_vec和tasklet_hi_vec的定义如下：

```C
struct tasklet_head {
	struct tasklet_struct *head;
	struct tasklet_struct **tail;
};

static DEFINE_PER_CPU(struct tasklet_head, tasklet_vec);
static DEFINE_PER_CPU(struct tasklet_head, tasklet_hi_vec);
```

这两个变量分别定义了两个存储tasklet_struct结构体的链表。结构体tasklet_struct定义如下：

```
struct tasklet_struct
{
	struct tasklet_struct *next;
	unsigned long state;
	atomic_t count;
	void (*func)(unsigned long);
	unsigned long data;
};
```
其中包含了五个成员变量，分别是：

* struct tasklet_struct *next：链表中下一个成员的指针。
* unsigned long state：tasklet的状态。
* atomic_t count：原子变量，表示这个tasklet当前是否活跃。
* void (*func)(unsigned long)：处理这个tasklet的回调函数。
* unsigned long data：回调函数参数。

## 触发tasklet
内核通过函数tasklet_schedule触发一个tasklet被执行：

```C
static inline void tasklet_schedule(struct tasklet_struct *t)
{
	if (!test_and_set_bit(TASKLET_STATE_SCHED, &t->state))
		__tasklet_schedule(t);
}
```

首先，使用test_and_set_bit函数判断t->state中的TASKLET_STATE_SCHED是否被置为1，如果没有则调用函数__tasklet_schedule调度tasklet来执行：

```C
// kernel/softirq.c
void __tasklet_schedule(struct tasklet_struct *t)
{
	unsigned long flags;

	local_irq_save(flags);
	t->next = NULL;
	*__this_cpu_read(tasklet_vec.tail) = t;
	__this_cpu_write(tasklet_vec.tail, &(t->next));
	raise_softirq_irqoff(TASKLET_SOFTIRQ);
	local_irq_restore(flags);
}
```
该函数首先和前面软中断的处理一样，保存IF标志位同时禁用中断，然后修改tasklet_vec链表，调用raise_softirq_irqoff触发TASKLET_SOFTIRQ类型的软中断执行，最后回复IF标志位同时启用中断。

在函数softirq_init中，两类用于处理tasklet的处理函数分别是：

```
	open_softirq(TASKLET_SOFTIRQ, tasklet_action);
	open_softirq(HI_SOFTIRQ, tasklet_hi_action);
```

接着看函数tasklet_action的实现：

```C
// kernel/softirq.c
static __latent_entropy void tasklet_action(struct softirq_action *a)
{
	struct tasklet_struct *list;

	local_irq_disable();
	list = __this_cpu_read(tasklet_vec.head);
	__this_cpu_write(tasklet_vec.head, NULL);
	__this_cpu_write(tasklet_vec.tail, this_cpu_ptr(&tasklet_vec.head));
	local_irq_enable();

	while (list) {
		struct tasklet_struct *t = list;

		list = list->next;

		if (tasklet_trylock(t)) {
			if (!atomic_read(&t->count)) {
				if (!test_and_clear_bit(TASKLET_STATE_SCHED,
							&t->state))
					BUG();
				t->func(t->data);
				tasklet_unlock(t);
				continue;
			}
			tasklet_unlock(t);
		}

		local_irq_disable();
		t->next = NULL;
		*__this_cpu_read(tasklet_vec.tail) = t;
		__this_cpu_write(tasklet_vec.tail, &(t->next));
		__raise_softirq_irqoff(TASKLET_SOFTIRQ);
		local_irq_enable();
	}
}
```

该函数的工作流程是：

1.	调用local_irq_disable禁用本地CPU的中断。
2.	从tasklet_vec链表头取出头元素list。
3.	调用local_irq_enable启用本地CPU的中断。
4.	接着，就是遍历整个tasklet_vec链表，依次处理这些tasklet了。每次取出一个tasklet的时候，也是像前面一样应用本地CPU的中断，取出之后再开启中断。


# workqueue
workqueue是另外一种延迟处理中断的机制。与tasklet相比，两者有以下的区别：

*	workqueue函数运行在内核进程上下文中（context of kernel process），而tasklet运行在中断上下文中。
*	tasklet都在它最初被触发的CPU中执行，而workqueue则没有这个限制。

## 数据结构
内核使用结构体worker_pool来管理所有CPU上面的worker，在这里仅列举其中的一部分成员：

```C
// kernel/workqueue.c
struct worker_pool {
	spinlock_t		lock;		/* the pool lock */
	int			cpu;		/* I: the associated cpu */
	int			node;		/* I: the associated node ID */
	int			id;		/* I: pool ID */
	unsigned int		flags;		/* X: flags */

	unsigned long		watchdog_ts;	/* L: watchdog timestamp */

	struct list_head	worklist;	/* L: list of pending works */
	int			nr_workers;	/* L: total number of workers */

	....
}
```

worker_pool中管理的每个worker如下定义：

```C
// kernel/workqueue_internal.h
struct worker {
	/* on idle list while idle, on busy hash table while busy */
	union {
		struct list_head	entry;	/* L: while idle */
		struct hlist_node	hentry;	/* L: while busy */
	};

	struct work_struct	*current_work;	/* L: work being processed */
	work_func_t		current_func;	/* L: current_work's fn */
	struct pool_workqueue	*current_pwq; /* L: current_work's pwq */
	bool			desc_valid;	/* ->desc is valid */
	struct list_head	scheduled;	/* L: scheduled works */

	....
}
```

每个CPU上运行的kworker进程：

```
$ ps aux | grep kworker
root         4  0.0  0.0      0     0 ?        I<   1月30   0:00 [kworker/0:0H]
root        18  0.0  0.0      0     0 ?        I<   1月30   0:00 [kworker/1:0H]
root        24  0.0  0.0      0     0 ?        I<   1月30   0:00 [kworker/2:0H]
```

## 添加任务到workqueue
内核提供函数queue_work将任务放入workqueue中：

```
// include/linux/workqueue.h
static inline bool queue_work(struct workqueue_struct *wq,
			      struct work_struct *work)
{
	return queue_work_on(WORK_CPU_UNBOUND, wq, work);
}
```

接着看函数queue_work_on：

```C
// kernel/workqueue.c
bool queue_work_on(int cpu, struct workqueue_struct *wq,
		   struct work_struct *work)
{
	bool ret = false;
	unsigned long flags;

	local_irq_save(flags);

	if (!test_and_set_bit(WORK_STRUCT_PENDING_BIT, work_data_bits(work))) {
		__queue_work(cpu, wq, work);
		ret = true;
	}

	local_irq_restore(flags);
	return ret;
}
```
它做的事情很简单，同样也是前后禁用、启用中断，在判断WORK_STRUCT_PENDING_BIT被置为1失败之后，调用__queue_work将任务放入workqueue：

```C
static void __queue_work(int cpu, struct workqueue_struct *wq,
			 struct work_struct *work)
{
	// ....

	if (req_cpu == WORK_CPU_UNBOUND)
		cpu = wq_select_unbound_cpu(raw_smp_processor_id());

	if (!(wq->flags & WQ_UNBOUND))
		pwq = per_cpu_ptr(wq->cpu_pwqs, cpu);
	else
		pwq = unbound_pwq_by_node(wq, cpu_to_node(cpu));

	// ...

	insert_work(pwq, work, worklist, work_flags);

	// ...
}
```

这里裁剪掉无关的代码，来看核心的部分：

*	首先，如果work加入时未指定要运行的CPU，通过wq_select_unbound_cpu进行选择，默认使用当前CPU。如果该CPU不在wq_unbound_cpumask (全局 cpumask)内，则从wq_unbound_cpumask中通过round robin方式选择。
*	对于 bound workqueue ，取出当前 per CPU变量中的pool_workqueue 。对于unbound workqueue，取出当前CPU 所在node对应的pool_workqueue。