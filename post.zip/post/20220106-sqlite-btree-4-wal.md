---
title: "sqlite3.36版本 btree实现（四）- WAL的实现"
date: 2022-01-06T21:48:18+08:00
tags: ["存储","存储引擎","sqlite","btree"]
categories: ["存储","存储引擎"]
keywords:
- Btree
- 存储引擎
- sqlite
description : "WAL的实现"

draft: true
---

# 概述
前面两节，分别讲解了sqlite中写入事务时的并发控制框架，以及journal备份文件的实现机制。

回忆一下journal备份文件的实现：

* 每次一个新的写事务开始之前，要首先写journal文件的文件头。
* 写事务过程中，如果修改了哪个页面，在修改之前需要首先将这个页面的内容写入到journal文件中。
* 写事务完成后，在同步所有缓存中被修改的页面到数据库文件之前，要首先将journal文件中的所有修改同步到磁盘，然后再修改数据库文件。

可以看到，journal备份的整个流程都较为原始，性能不高，所以在sqlite 3.7.0版本（[SQLite Release 3.7.0 On 2010-07-21](https://www.sqlite.org/releaselog/3_7_0.html)，2010-07-21）中，引入了另一种备份机制：WAL（Write Ahead Log）。

本节首先介绍WAL的实现原理，然后再展开其具体的实现。



对比起journal机制，WAL有如下的优缺点：



* 优点：
* 缺点：

# WAL工作原理
从前面journal的实现中可以看到，写入journal文件中的内容，是待修改页面修改之前的内容，而WAL则相反：被修改的页面内容首先写入到WAL中。



用sqlite官网的文字来说，WAL文件的定义是这样的：

> The write-ahead log or "wal" file is a roll-forward journal that records transactions that have been committed but not yet applied to the main database. 

即WAL文件中存储的是被修改但是还没有写入数据库文件的页面内容。



WAL整体的实现机制，分为以下几个流程：

* 对页面的修改，可以只写入到WAL文件中就认为完成，不必一定要落盘到数据库文件才能算完成，这个设定保证了WAL的修改操作比journal性能有很大的提升。
* 由于上面的这一点保证，同一时间的并发读操作，能继续读数据库中未修改的内容，极大提升了读并发的性能。
* 当然WAL也不能无限制的一直写下去，必须有一个机制，触发将保存在WAL中的页面内容写入回到数据库文件中，这个流程被称为“checkpoint”。



## WAL相关文件结构

在工作原理部分，只会简单讲解WAL相关文件结构，具体的格式等细节留待下面的实现部分详细讲解。



WAL文件本身的格式很简单，有如下两部分组成：



* WAL文件头。
* 紧跟着文件头之后的，就是由修改之后的页面内容组成的页面内容数组。
* 最后，当事务被提交时，还会有一个特殊的WAL日志，标记这个事务提交了。



换言之，一个WAL中，可能先后存储了多个事务的写入。





由于WAL文件保存的**修改页面**的内容，同一个页面，可能在一次事务中被多次修改，如下所示：



<center>
![WAL及WAL页面索引数据](/media/imgs/20220106-sqlite-btree-4-wal/wal-and-index.png "WAL及WAL页面索引数据")
</center>



WAL存储了四个页面数据，其中页面编号1被修改了两次。



如果在这个写操作完成之后，需要读这些页面的内容，都需要读到最新的内容。所以，WAL还有一个对应的`WAL页面索引`数据，这部分索引数据存储在内存中，作用是根据页面编号，知道该页面编号对应的最新内容，存储在WAL文件中的具体位置，以取得某个页面的最新页面内容；如果在这个内存索引中查不到的数据，都需要到数据库文件中读取。



## checkpoint

随着WAL文件的增长，终究要将里面修改的内容同步到数据库文件中，这个流程被称为“checkpoint”。只要WAL文件被“checkpoint”，就可以从头开始写这个文件，避免文件的无限增大。



对于journal备份机制而言，只有两种操作：读和写；而对于WAL机制而言，实际有三种操作：读、写、checkpoint。这也是两种机制的主要区别之一。



## 并发的实现

前面提到了，WAL机制的一个优势在于：在写未完成之前，可以允许同时并发多个读操作，来看看这一点是如何做到的。



在每次读操作开始之前，都会记录下来当前最后提交事务的提交记录，这条记录被称为“end mark”。因为WAL会随着写操作的进行不断增加，通过读操作的“end mark”，就能知道对于这个读操作而言，页面内容应该以当前WAL内容为准，还是以数据库文件为准。



以下图为例来做个说明：



<center>
![读并发的实现](/media/imgs/20220106-sqlite-btree-4-wal/read-concurrency.png "读并发的实现")
</center>





在上图中：

* WAL文件中先后记录了两个写事务，其中第一个写事务修改了页面编号1、2，已经提交完成；还有一个在进行还未完成的写事务，修改了页面编号1。
* 这时候，如果来了一个读事务，那么将记录下来最后一个完成事务的提交记录做为自己的“end mark”，即图中的浅蓝色的那个提交记录。
* 假设现在这个读事务，依次要读取页面编号1和2的页面，那么：
  * 到页面索引中查询页面1的位置，发现位置比自己的“end marker”更大，也就是说这个页面在上一次完成写事务之后，被当前还未完成的写事务修改了，于是并不能读WAL的内容，因为这部分内容对这个读操作来说还是未提交的，所以页面1需要到数据库文件中读取。
  * 到页面索引中查询页面2的位置，发现位置比自己的“end marker”更小，也就是在自己标记的写事务完成之后并未被修改过，于是可以读WAL中这个页面的内容。



可见，有了“end mark”这一标记位置之后，加上页面索引，任意数量的读操作都能快速判断自己应该读WAL文件还是数据库文件，写操作可以继续写，读和写之间并不会冲突，极大提升了读并发的性能。



同样要看到的是，由于只有一个WAL文件，同一时间之内，只能有一个写操作。即：**sqlite的WAL模式，只能支持单写多读的模式。**



## 读操作和checkpoint的联系

前面讲到了checkpoint以及读并发的实现，两者可以并发一起执行，但是某些时刻会有一些关联，影响系统的性能。



既然超过读操作“end mark”的页面，读操作需要到数据库文件中读取该页面内容，那么反过来，当checkpoint操作要将一个超过当前并发的**任意读操作**“end mark”的页面落到数据库文件中时，就必须等待这个读操作完成才能进行。



仍然以前面读并发的示意图来解释这个过程：

* checkpoint 页面编号2的内容到数据库文件时，该页面最后在WAL文件中的位置，并不比当前的任意读操作的“end mark“更大，所以checkpoint这个页面的内容到数据库文件时无需等待即可完成。
* 反过来，checkpoint 页面编号1的内容到数据库文件时，该页面最后在WAL文件中的位置，大于当前读操作的”end mark“，所以这个页面的内容就需要等待读操作完成才能进行下去。



换言之：一个执行很久的读操作，可能会影响同时在进行的checkpoint操作的执行。



被阻塞的checkpoint必须等待读操作完成才能继续执行，因此需要一些额外的信息来维护当前checkpoint执行的状态，这些具体的实现细节都会在下面实现环节的分析中涉及。



现在已经大体清楚WAL的原理了，下面来看具体的实现。



# WAL的实现

sqlite中，可以使用`PRAGMA journal_mode=wal`设置页面备份机制为wal，这时候就会有三个与数据库相关的文件在同一个目录：



* 数据库文件，假设名字为X。
* WAL文件，名字为“X-wal”。
* wal索引文件，名字为“X-shm”。





## WAL页面索引



### 结构



WAL文件中，保存一页数据的内容被称为“帧（frame）”，帧的编号从1开始顺序递增，每一帧内容存储的页面内容可能会发生变化，如下图所示：





<center>
![帧与页面的对应关系](/media/imgs/20220106-sqlite-btree-4-wal/wal-frame.png "帧与页面的对应关系")
</center>



图中，依次有四帧页面数据，与页面的对应关系依次是：(1,1)，(2,3)，(3,5)，(4,4)。假设随着运行，第一帧对应的页面1被写入了数据库，那么第一帧的空间就会被复用来存储别的页面的内容。



所以，WAL页面索引中，需要存储帧数与页面编号之间的对应关系，这样就能：

* 访问一帧的内容时，知道保存的是哪个页面的内容；
* 根据页面编号，能查到这个页面在哪一帧中。



根据需要的这两份数据，定义了用于保存wal索引的数据结构：



```C
struct WalHashLoc {
  volatile ht_slot *aHash;  /* Start of the wal-index hash table */
  volatile u32 *aPgno;      /* aPgno[1] is the page of first frame indexed */
  u32 iZero;                /* One less than the frame number of first indexed*/
};
```

其中：

* aHash：保存了根据页面编号查找iFrame帧数的hash数组数据。
* aPgno：保存了根据帧数查找页面编号的数据。
* iZero：保存了当前索引页面第一帧的帧数。



这么看来有一些抽象，我们以下图来做解释wal-index文件的结构：



<center>
![WAL-Index索引文件结构图](/media/imgs/20220106-sqlite-btree-4-wal/wal-index-format.png "WAL-Index索引文件结构图")
</center>



如上图所示，其中：

* wal索引文件一页大小为32KB，需要注意的是：不要把wal索引文件的一页与数据库文件的一页搞混，两者并不一定相同，但是都为2的次方，数据库文件的一页可以编译期修改，但是wal索引文件的一页大小写死为32KB。
* 第一页相对有些特殊，因为最开始的136字节是wal索引文件头，所以相对的，剩下用来存储索引数据的空间就会变少一些。索引文件头的内容，留待后面再详细解释。
* 每一页存储的数据中，`aPgno`大小为4096（第一页只有4062，因为有头部用到的空间），`aHash`的大小为8192。



这几个常量，由下面这几个宏来定义：



```c
// 每一页aPgno数组大小
#define HASHTABLE_NPAGE      4096                 /* Must be power of 2 */
// 查询时hash取模时的质数
#define HASHTABLE_HASH_1     383                  /* Should be prime */
// 每一页hash slot数组大小
#define HASHTABLE_NSLOT      (HASHTABLE_NPAGE*2)  /* Must be a power of 2 */

// 页面1实际能容纳的aPgno大小：HASHTABLE_NPAGE减去WALINDEX_HDR_SIZE使用的大小
#define HASHTABLE_NPAGE_ONE  (HASHTABLE_NPAGE - (WALINDEX_HDR_SIZE/sizeof(u32)))

// 一个wal索引页面的大小，为4096*4+8192*2 = 32KB
#define WALINDEX_PGSZ   (                                         \
    sizeof(ht_slot)*HASHTABLE_NSLOT + HASHTABLE_NPAGE*sizeof(u32) \
)
```



### 实现

有了前面的准备，我们来看看这两种对应关系的查找是怎么做的。





## 锁的实现



## WAL的文件格式



## 





# 参考资料



* [Write-Ahead Logging](https://www.sqlite.org/wal.html)
* WAL文件格式见：[Database File Format](https://www.sqlite.org/fileformat2.html)中“4. The Write-Ahead Log”这一小节内容。
* [SQLite分析之WAL机制_岩之痕-CSDN博客_sqlite wal](https://blog.csdn.net/zearot/article/details/51039593)







