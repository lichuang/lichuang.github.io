---
weight: 100
title: "博客系列文章索引"
date: 2020-01-22T14:36:00+08:00
keywords:
- linux
- systemtap
- etcd
- raft
- IM
- 内存模型
- 服务调用
- Nginx
- ZeroMQ
- libuv
- 数据密集型应用系统设计
- 如何阅读一份源代码
description : "博客系列文章索引"
---

在博客已经写了很多文章了，有一些文章独立成体，有一些则是系列文章来讲述一个主题，在这里将这些系列文章整理下来，本页面将不定期更新。

# Linux系统相关

## 面向应用开发者的系统指南
* [《面向应用开发者的系统指南》导论&目录](https://www.codedump.info/post/20200501-system-guide-for-application-programmer/)

### 基础篇
* [通过实例快速入门Systemtap](https://www.codedump.info/post/20200128-systemtap-by-example/)
* [Systemtap中内核trace事件的实现](https://www.codedump.info/post/20200218-linux-traceevent/)

### CPU篇
* [进程](https://www.codedump.info/post/20200502-sgfap-process/)
* [进程调度](https://www.codedump.info/post/20200503-sgfap-process-schedule/)
* [使用systemtap分析进程的行为](https://www.codedump.info/post/20200503-sgfap-process-systemtap/)
* [系统调用](https://www.codedump.info/post/20200516-sgfap-syscall/)
* [软中断](https://www.codedump.info/post/20200522-sgfap-softirq/)

# 分布式相关

## etcd及Raft原理

* [Raft算法原理](https://www.codedump.info/post/20180921-raft/)
* [etcd Raft库解析](https://www.codedump.info/post/20180922-etcd-raft/)
* [Etcd存储的实现](https://www.codedump.info/post/20181125-etcd-server/)
* [Etcd Raft库的工程化实现](https://www.codedump.info/post/20210515-raft/)
* [Etcd Raft库的日志存储](https://www.codedump.info/post/20210628-etcd-wal/)
* [为什么Raft协议不能提交之前任期的日志？](https://www.codedump.info/post/20211011-raft-propose-prev-term/)
* [etcd 3.5版本的joint consensus实现解析](https://www.codedump.info/post/20220101-etcd3.5-joint-consensus/)



# 存储引擎

## 理论基础
* [B树、B+树索引算法原理（上）](https://www.codedump.info/post/20200609-btree-1/)
* [B树、B+树索引算法原理（下）](https://www.codedump.info/post/20200615-btree-2/)



## sqlite

* [sqlite3.36版本 btree实现（零）- 起步及概述](https://www.codedump.info/post/20211217-sqlite-btree-0/)
* [sqlite3.36版本 btree实现（一）- 管理页面缓存](https://www.codedump.info/post/20211217-sqlite-btree-1-pagecache/)
* [sqlite3.36版本 btree实现（二）- 并发控制框架](https://www.codedump.info/post/20211218-sqlite-btree-2-concurrency-control/)
* [sqlite3.36版本 btree实现（三）- journal文件备份机制](https://www.codedump.info/post/20211222-sqlite-btree-3-journal/)



## leveldb
* [Leveldb代码阅读笔记](https://www.codedump.info/post/20190215-leveldb/)



## boltdb
* [boltdb 1.3.0实现分析（一）](https://www.codedump.info/post/20200625-boltdb-1/)
* [boltdb 1.3.0实现分析（二）](https://www.codedump.info/post/20200711-boltdb-2/)
* [boltdb 1.3.0实现分析（三）](https://www.codedump.info/post/20200725-boltdb-3/)
* [boltdb 1.3.0实现分析（四）](https://www.codedump.info/post/20200726-boltdb-4/)



# 缓存服务

## memcached

* [Memcached的存储原理解析](https://www.codedump.info/post/20210701-memcached/)
* [Memcached的存储原理解析（续）](https://www.codedump.info/post/20210812-memcached/)

# 系统设计相关

## IM服务器设计

* [IM服务器设计-基础](https://www.codedump.info/post/20190608-im-design-base/)
* [IM服务器设计-消息存储](https://www.codedump.info/post/20190608-im-msg-storage/)
* [IM服务器设计-网关接入层 ](https://www.codedump.info/post/20190818-im-msg-gate/)
* [IM服务器设计-如何解决消息的乱序](https://www.codedump.info/post/20191013-im-msg-out-of-order/)

## 服务调用
* [服务调用的演进历史](https://www.codedump.info/post/20190629-service-history/)

# 多核编程

## 内存模型
* [C++11中的内存模型上篇 - 内存模型基础](https://www.codedump.info/post/20191214-cxx11-memory-model-1/)
* [C++11中的内存模型下篇 - C++11支持的几种内存模型](https://www.codedump.info/post/20191214-cxx11-memory-model-2/)

# 源码解析类
## Etcd
* [etcd Raft库解析](https://www.codedump.info/post/20180922-etcd-raft/)
* [Etcd存储的实现](https://www.codedump.info/post/20181125-etcd-server/)

## Nginx && OpenResty
* [Nginx源码阅读笔记-配置解析流程 ](https://www.codedump.info/post/20190103-nginx-config-parse/)
* [Nginx源码阅读笔记-Master Woker进程模型](https://www.codedump.info/post/20190131-nginx-master-worker/)
* [Nginx源码阅读笔记-事件处理模块](https://www.codedump.info/post/20190131-nginx-event/)
* [Nginx源码阅读笔记-接收HTTP请求流程](https://www.codedump.info/post/20190131-nginx-read-http-request/)
* [Nginx源码阅读笔记-查询HTTP配置流程](https://www.codedump.info/post/20190212-nginx-http-config/)
* [Nginx源码阅读笔记-处理HTTP请求](https://www.codedump.info/post/20190213-nginx-process-http-request/)
* [Nginx源码阅读笔记-内存池的设计](https://www.codedump.info/post/20190214-nginx-memory-pool/)
* [OpenResty Lua Stream实现分析](https://www.codedump.info/post/20190501-lua-stream/)

## Zeromq
* [zeromq所谓的“无锁消息队列”](https://www.codedump.info/post/20190209-zeromq-lockfree-queue/)


## Redis
* [redis高可用原理](https://www.codedump.info/post/20190409-redis-sentinel/)

## Glog
* [glog C++版本代码分析](https://www.codedump.info/post/20190729-glog/)

## Libuv
* [Libuv代码简单分析](https://www.codedump.info/post/20190123-libuv/)

# 读书笔记
## 《数据密集型应用系统设计》
* [《数据密集型应用系统设计》第五章数据复制笔记](https://www.codedump.info/post/20181118-ddia-chapter05-replication/)
* [《数据密集型应用系统设计》第六章数据分区笔记](https://www.codedump.info/post/20181124-ddia-chapter06-partitioning/)
* [《数据密集型应用系统设计》第七章《事务》笔记](https://www.codedump.info/post/20190403-ddia-chapter07-transaction/)
* [《数据密集型应用系统设计》第八章《分布式系统的挑战》笔记](https://www.codedump.info/post/20190405-ddia-chapter08-the-trouble-with-distributed-system/)
* [《数据密集型应用系统设计》第九章《一致性与共识》笔记 ](https://www.codedump.info/post/20190406-ddia-chapter09-consistency-and-consensus/)

# 杂

* [如何阅读一份源代码？](https://www.codedump.info/post/20190324-how-to-read-code/)
* [如何阅读一份源代码？（2020年版）](https://www.codedump.info/post/20200605-how-to-read-code-v2020/)