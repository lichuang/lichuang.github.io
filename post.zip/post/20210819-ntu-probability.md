---
title: "台湾大学概率课笔记"
date: 2021-08-19T23:17:48+08:00
draft: true
---

# 概率导论

## 为什么要学习概率？

* 对世界的了解太少，世界的运作有很多是未知的。
* 世间的很多事情不见得是必然的（deterministic），有很多事情是随机的（random）。

## 概率与统计

* 概率：概率模型已知，计算出事件的概率。
* 统计：概率模型未知，从大量的实验结果（样本）中建立概率模型。

## 集合论
概率函数的自变量是事件，而事件是一种集合。

## 概率名词

* 实验：一个概率实验包括以下三部分，步骤、模型、观察。
* 结果：实验中可能的结果。
* 样本空间（sample space）：概率实验可能结果的集合。
* 事件（event）：事件可以看做是结果的集合，也就是样本空间的子集。
* 事件空间（event space）：包括所有事件的集合。
* 概率是一个函数，这个函数的自变量是事件，输出是[0,1]之间的概率。

# 概率性质和条件概率

## 概率性质
### 公理
* 公理常是不能被证明的基本性质
* 公理常是非常基本的性质
* 公理越少、越基本、越厉害

### 概率三公理

<center>
![概率三公理](/media/imgs/20210819-ntu-probability/gongli.png "概率三公理")
</center>

即：

* 任何事件发生的概率都>=0。
* 所有事件加起来的概率为1。
* 所有互斥事件的概率之和，等于这些事件集合的概率。

第三条公理的例子如下：

扑克牌中抽出ACE的概率，等于四种不同颜色的ACE概率之和

<center>
![概率三公理](/media/imgs/20210819-ntu-probability/ace.png "概率三公理")
</center>

### 切面包定理

<center>
![切面包定理](/media/imgs/20210819-ntu-probability/qiemianbao.png "切面包定理")
</center>


## 条件概率
### 条件概率的定义
概率常反映出我们对事情的了解程度。比如，对于没读书的人来说，选择题四个选项，每个选项正确的概率为1/4，但是对于读书的人来说，能轻松排除掉其中的几个答案，即这几个答案对他们来说概率不是平均的。

条件概率：在得知其他事情发生之后，对某些事情的了解有所改变。更精准的定义如下：

<center>
![条件概率](/media/imgs/20210819-ntu-probability/condition.png "条件概率")
</center>

### 条件概率的性质

<center>
![条件概率的性质](/media/imgs/20210819-ntu-probability/condition-property.png "条件概率的性质")
</center>

### 全概率定理（total probability）

<center>
![全概率](/media/imgs/20210819-ntu-probability/total.png "全概率")
</center>

### 贝叶斯定理（bayes' rule）

<center>
![贝叶斯定理](/media/imgs/20210819-ntu-probability/bayes.png "贝叶斯定理")
</center>

```
贝叶斯理论，用很简单的一句话来解释，就是用来“翻转条件概率”的。

假设，在男性中，色盲的概率为5%，而在女性中，色盲的概率为0.5%。而人群中的男女比例为1：1。那么请问，如果一位患者是色盲，那么他是男性的概率有多少？

在已知的信息中，我们知道在男性中色盲的概率5%，这是条件概率。我们需要计算的是在色盲中为男性的概率，这也是条件概率，但是条件翻转了，条件从“男性”变为了“色盲”。


```

贝叶斯理论之所以有名，是因为他可以用一些我们已知的条件概率，去计算一些未知的条件概率。

[零公式讲解统计学——贝叶斯理论（Bayes’ Theorem） - 简书](https://www.jianshu.com/p/345cbb7d8737)


# 概率的独立性和计算

## 概率的独立性
两种定义概率独立性的方式：

集合方式：两事件交集的概率，等于两事件概率的积，则说明两事件是独立的。

<center>
![集合方式定义概率独立性](/media/imgs/20210819-ntu-probability/independence-1.png "集合方式定义概率独立性")
</center>

条件概率方式：在事件B发生的条件下，事件A发生的概率，等于事件A发生的概率，也说明A、B两事件是独立事件。

<center>
![条件概率方式定义概率独立性](/media/imgs/20210819-ntu-probability/independence-2.png "条件概率方式定义概率独立性")
</center>

可以把上面两事件独立的定义推广到多个事件独立性的计算上：

<center>
![多事件概率独立性](/media/imgs/20210819-ntu-probability/multi-independence.png "多事件概率独立性")
</center>

## 概率的计算

* 古典概率：假设每个实验结果发生的概率相同。

### 概率计算的前提

* 所有的物件是否可区分？（distinguishable？）
* 实验中抽取的物件是否可以放回去供下次继续抽取？（with/without replacement？）
* 实验中被抽取的物件，抽取顺序是否有差异？（order matters or not？）

### 排列（permutation）
有n物品，从中依序取出k个，共有多少种结果？

`n*(n-1)*...*(n-k-1)`

### 重复抽取（choose with replacement）
有n物品，从中抽取一个，每次取完都放回去，依序取出k个，共有多少种结果？

`n*n*...n = n^k` 

### 组合（combination）
有n物品，从中取出k个，共有多少种结果？

`n*(n-1)*...*(n-k-1)/k!=n!/(n-k)!k!`，即二项系数。


### 多项组合（multinomial）

<center>
![多项组合](/media/imgs/20210819-ntu-probability/multinomial.png "多项组合")
</center>
